pretrained_models = {
    "srresnet_bicubic_x4": "https://image-super-resolution-weights.s3.af-south-1.amazonaws.com/srresnet_bicubic_x4/generator.h5",
    "srgan_bicubic_x4": "https://image-super-resolution-weights.s3.af-south-1.amazonaws.com/srgan_bicubic_x4/generator.h5",
}